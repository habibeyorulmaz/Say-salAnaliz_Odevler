/*
 * Habibe YORULMAZ
 * 		121044040
 * sayisal 3. odev part2
 */
#include<stdio.h>
#include<math.h>
#define ESP 0.001
#define F3(x) (x)*(x)*(x)*(x)*(x)*(x)*(x) - 1
#define F4(x) (x)*(x)*(x)*(x) + 7*(x)*(x)*(x) + 18*(x)*(x) -20*(x) +8
#define F5(x) pow(x,6) + 2*pow(x,5) + pow(x,4) + 3*pow(x,3) + 5*pow(x,2) +x +1

int main()
{
  double x0,x1,x2,x3_1,x3_2,fx0,fx1,fx2,
     h1,h2,h3_1,h3_2,h4,D,d1,d2,a1,a2,a0;
  int i=1;
 
  printf("\nPlease enter the value of x0: ");
  scanf("%lf",&x0);
  printf("\nPlease enter the value of x1: ");
  scanf("%lf",&x1);
  printf("\nPlease enter the value of x2: ");
  scanf("%lf",&x2);
  fx0 = F5(x0);
  printf("\n\n f(x0) = %f",fx0);

  fx1 = F5(x1);
  printf("\n\n f(x1) = %f",fx1);
 
  fx2 = a0 = F5(x2);
  printf("\n\n f(x2) = %f",fx2);
  
  h1 = x0-x2;
  h2 = x1-x2;

  d1 = fx0-fx2;
  d2 = fx1-fx2;

  D = h1*h2*(h1-h2);

  a1 = (d2*h1*h1 - d1*h2*h2)/D;
  a2 = (d1*h2 - d2*h1)/D;

  h3_1 = -((2*a0)/(a1 + sqrt(fabs(a1*a1 - (4*a2*a0)))));
  h3_2 = -((2*a0)/(a1 - sqrt(fabs(a1*a1 - (4*a2*a0)))));

  if( (a1 + sqrt(fabs(a1*a1 - (4*a2*a0)))) >
         ((a1 - sqrt(fabs(a1*a1 - (4*a2*a0))))) )
  {
   h4 = h3_1;
  }
  else
   {
   h4 = h3_2;
  }
  x3_1 = x2 + h4;
  printf("\n\n\n x4 = %f \n",x3_1);

  x0=x1;
  x1=x2;
  x2=x3_1;
  printf("\n\nx0 = %f",x0);
  printf("\n\nx1 = %f",x1);
  printf("\n\nx2 = %f",x2);

  do
  {
   fx0 = F5(x0);
   fx1 = F5(x1);
   fx2 = a0 = F5(x2);

   h1 = x0-x2;
   h2 = x1-x2;

   d1 = fx0-fx2;
   d2 = fx1-fx2;

   D = h1*h2*(h1-h2);

   a1 = (d2*h1*h1 - d1*h2*h2)/D;
   a2 = (d1*h2 - d2*h1)/D;

   h3_1 = -((2*a0)/(a1 + sqrt(fabs(a1*a1 - (4*a2*a0)))));
   h3_2 = -((2*a0)/(a1 - sqrt(fabs(a1*a1 - (4*a2*a0)))));

   if( (a1 + sqrt(fabs(a1*a1 - (4*a2*a0)))) >
         (a1 - sqrt(fabs(a1*a1 - (4*a2*a0)))) )
   {
    h4 = h3_1;
   }
   else
   {
    h4 = h3_2;
   }
   x3_2 = x2 + h4;
   
     printf("\n\n\n x4 = %f \n",x3_2);
   if(fabs(x3_1 - x3_2) < ESP)
   {
    printf("\n\nREAL ROOT = %.3f\n",x3_2);
    i=0;
   }
   else
   {
     x3_1=x3_2;
     x0=x1;
     x1=x2;
     x2=x3_1;
     printf("\n\nx0 = %f",x0);
     printf("\n\nx1 = %f",x1);
     printf("\n\nx2 = %f",x2);
   }
  }while(i!=0);
}
