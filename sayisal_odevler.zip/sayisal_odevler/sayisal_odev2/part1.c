/*
 * HABIBE YORULMAZ
 * 121044040
 */
#include<stdio.h>
#include<math.h>
#define ESP 0.001
#define F1(x) (x)*(x)*(x)*(x)*(x) - 3*(x)*(x)*(x)  + (x)*(x) - 1
#define F2(x) (x)*(x)*(x) + 3*(x) - 1

int main()
{
  double x0,x1,x2,x3_1,x3_2;
  double fx0,fx1,fx2;
  double h1,h2,h3_1,h3_2,h4;
  double D,d1,d2,a1,a2,a0;
  int count=1;
 
  printf("\nPlease enter the value of x0: ");
  scanf("%lf",&x0);
  
  printf("\nPlease enter the value of x1: ");
  scanf("%lf",&x1);
  
  printf("\nPlease enter the value of x2: ");
  scanf("%lf",&x2);
  fx0 = F1(x0);
  printf("\n\nResult: \n");
  printf("f(x0) = %.2f",fx0);

  fx1 = F1(x1);
  printf("\nf(x1) = %.2f",fx1);
 
  fx2 = a0 = F1(x2);
  printf("\nf(x2) = %.2f",fx2);
  
  h1 = x0-x2;
  h2 = x1-x2;

  d1 = fx0-fx2;
  d2 = fx1-fx2;

  D = h1*h2*(h1-h2);

  a1 = (d2*h1*h1 - d1*h2*h2)/D;
  a2 = (d1*h2 - d2*h1)/D;

  h3_1 = -((2*a0)/(a1 + sqrt(fabs(a1*a1 - (4*a2*a0)))));
  h3_2 = -((2*a0)/(a1 - sqrt(fabs(a1*a1 - (4*a2*a0)))));

  if( (a1 + sqrt(fabs(a1*a1 - (4*a2*a0)))) >
         ((a1 - sqrt(fabs(a1*a1 - (4*a2*a0))))) )
  {
   h4 = h3_1;
  }
  else
   {
   h4 = h3_2;
  }
  x3_1 = x2 + h4;
  printf("\n\n\nResult: \n");
  printf(" x4 = %.2f \n",x3_1);

  x0=x1;
  x1=x2;
  x2=x3_1;
  printf("\n\nResult: \n");
  printf("x0 = %.2f",x0);
  printf("\nx1 = %.2f",x1);
  printf("\nx2 = %.2f",x2);

  do
  {
   fx0 = F1(x0);
   fx1 = F1(x1);
   fx2 = a0 = F1(x2);

   h1 = x0-x2;
   h2 = x1-x2;

   d1 = fx0-fx2;
   d2 = fx1-fx2;

   D = h1*h2*(h1-h2);

   a1 = (d2*h1*h1 - d1*h2*h2)/D;
   a2 = (d1*h2 - d2*h1)/D;

   h3_1 = -((2*a0)/(a1 + sqrt(fabs(a1*a1 - (4*a2*a0)))));
   h3_2 = -((2*a0)/(a1 - sqrt(fabs(a1*a1 - (4*a2*a0)))));

   if( (a1 + sqrt(fabs(a1*a1 - (4*a2*a0)))) >
         (a1 - sqrt(fabs(a1*a1 - (4*a2*a0)))) )
   {
    h4 = h3_1;
   }
   else
   {
    h4 = h3_2;
   }
   x3_2 = x2 + h4;
   
   printf("\n\n\nResult: \n");
   printf("x4 = %.2f \n",x3_2);
   if(fabs(x3_1 - x3_2) < ESP)
   {
		printf("\n*************************************");
    	printf("\nTHE REAL ROOT = %.2f\n",x3_2);
    	printf("*************************************\n\n");
    	count=0;
   }
   else
   {
     x3_1=x3_2;
     x0=x1;
     x1=x2;
     x2=x3_1;
     
     printf("\n\n\nResult: \n");
     printf("x0 = %.2f \n",x0);
     printf("x1 = %.2f\n",x1);
     printf("x2 = %.2f\n",x2);
   }
  }while(count!=0);
}

