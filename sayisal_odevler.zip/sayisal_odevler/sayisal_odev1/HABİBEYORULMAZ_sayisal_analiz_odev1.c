﻿/*
	SAYISAL ANALİZ ÖDEV1
	HABİBE YORULMAZ 121044040	
	
	Kodun çalıştırlıması sonucu:
habibe@ubuntu:~/Desktop$ gcc -o sayisalodev sayisal_analiz_odev1.c -lm
habibe@ubuntu:~/Desktop$ ./sayisalodev 
iterasyon sayısı : 13
Root of equation1s=0.5885
iterasyon sayısı : 6
Root of equation1s=0.5886
iterasyon sayısı : 6
Root of equation1s=0.5885
iterasyon sayısı : 4
Root of equation1s=0.5885
habibe@ubuntu:~/Desktop$ 
	
	/// tüm kodları birinci denklem için denedim sonuçlar yukarıda
		karşılaştırma sonucunda secant methodunun daha çabuk yapıldığı görünüyor.

*/


#define TOLERANCE 0.0001 /*Hata payi*/
#define DERIVATIVE_OF_THE_EQUATION_1 0.99 /*Denklemin turevinde*/
                                                 /*1 yazdigimizda cikan sonuc*/
#include <stdio.h>
#include <math.h>

double equation1(double n); /*Odevde verilen birinci denklem*/
double equation2(double n); /*Odevde verilen ikinci denklem*/
double equation3(double n); /*Odevde verilen ucuncu denklem*/
double iteration(double n); /*One-Point Iteration icin iterasyon denklemi (1.2)^n yalniz birakildi*/
void bisection(void);
void falsePosition(void);
void newton_raphion(void);
void secantMethod(void);

int
main(void)
{
bisection();           /*Butun yontemler main fonksiyonda cagirildi*/
falsePosition();
newton_raphion();
secantMethod();
return(0);
}

double
equation1(double n) /*denklem*/
{
/*
return((((-3000*pow(1.2,n))+(175*n))/(pow(1.2,n)-1))+5000);
*/

return ( exp(-n) - sin(n));
}

double equation2(double n){

return (n - exp( 0 - ( pow(n, 2) ) ) );
}

double equation3(double n) {

return ( pow(n,3) - n - 2 );
}

double 
iteration(double n) /*iterasyon denklemi*/
{
return((log((5000-175*n)/2000))/(log(1.2)));
}

void
bisection(void) 
{
    double buyukSayi=0,kucukSayi=1,ortalama; 
	int i=0;
do  {
    ortalama=(buyukSayi+kucukSayi)/2; /*Verilen degerlerin ortalamasini aliyor*/

    if(equation1(buyukSayi)*equation1(ortalama)>0) /*Eger buyuk sayi ile ortalamanin denlemdeki sonuclari*/
        buyukSayi=ortalama;                      /*0'dan buyukse ortalamayi buyuk sayi yapiyor*/
    else										 /*degilse kucuk sayi yapiyor boylece araligi daraltiyor*/											
        kucukSayi=ortalama;                      /*while kosulu saglanana kadar yeni ortalama bulunuyor*/
	++i;
    }while(fabs(equation1(ortalama))>TOLERANCE); /*son ortalama deger 0'a hata payi kadar yakinsa onu kök */
            		                               /*olarak ekrana basiyor*/
            		                              
printf("iterasyon sayısı : %d\n", i);
printf("Root of equation1s=%.4f\n",ortalama);
}

void
falsePosition(void)
{
    double x1=0,x2=1,x3; /*rastgele iki deger atiyoruz*/
	int i=0;
do  {
    x3=x2-((equation1(x2)*(x1-x2))/(equation1(x1)-equation1(x2))); /*x3 degerini false position formulune gore buluyoruz*/

    if(equation1(x1)*equation1(x3)>0) /*Eger x1 ile x3 denlemdeki sonuclari*/
        x1=x3;                      /*0'dan x3'u x1 yapiyor*/
    else                            /*degilse x2 yapiyor boylece araligi daraltiyor*/	
        x2=x3;                      /*while kosulu saglanana kadar yeni x3 bulunuyor*/
	++i;
    }while(fabs(equation1(x3))>TOLERANCE); /*son x3 0'a hata payi kadar yakinsa onu kök */
printf("iterasyon sayısı : %d\n", i);               /*olarak ekrana basiyor*/
printf("Root of equation1s=%.4f\n",x3);
}

void
newton_raphion(void)
{
    double a=1,b; /*turevi 1 icin yaptigimdan a'ya 1 degerini atiyorum*/
	int i=0;
do  {
    b=(a - (equation1(a) / DERIVATIVE_OF_THE_EQUATION_1)); /*Formule gore b degerini buluyorum*/

    a=b; /*Dongu devam ederse yeni a degerimiz eski b degeri oluyor*/
        ++i;                                 /*while kosulu saglanana kadar yeni b bulunuyor*/
    }while(fabs(equation1(b))>TOLERANCE); 
       					              /*son b 0'a hata payi kadar yakinsa onu kök */
printf("iterasyon sayısı : %d\n", i);    
printf("Root of equation1s=%.4f\n",b);    /*olarak ekrana basiyor*/
}

void
secantMethod(void)
{
    double a=0,b=1,c; /*rastgele iki deger atiyoruz*/
	int i=0;
do  {
    c=(a*equation1(b)-b*equation1(a))/(equation1(b)-equation1(a)); /*secant yonteminin fotmulune gore*/
                                                               /*c degeri buluyoruz*/
    b=a; /*c degeri yeni a, a degeri yeni b oluyor*/
    a=c; /*while kosulu saglanana kadar yeni c bulunuyor*/
	++i;
    }while(fabs(equation1(c))>TOLERANCE); /*son b 0'a hata payi kadar yakinsa onu kök */
printf("iterasyon sayısı : %d\n", i);                    /*olarak ekrana basiyor*/
printf("Root of equation1s=%.4f\n",c); 
}

